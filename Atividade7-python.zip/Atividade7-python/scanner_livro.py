import re

def main():
    try:
        # 1. Abrir o arquivo com o encoding correto
        with open('livro.txt', 'r', encoding='utf-8') as arquivo:
            conteudo = arquivo.read()

        # 2. Regex: Pega palavras (com acentos) OU pontuações isoladas
        # [a-zA-ZÀ-ÿ]+ -> Palavras
        # [.,!?;:()"-] -> Pontuações comuns
        regexp = r'[a-zA-ZÀ-ÿ]+|[.,!?;:()"-]'
        
        # 3. Gerar a lista de tokens (O Vetor de Strings)
        tokens = re.findall(regexp, conteudo)

        # 4. Exibir resultados para o relatório
        print(f"--- SCANNER DE LIVRO ---")
        print(f"Total de tokens gerados: {len(tokens)}")
        print("\nPrimeiros 50 tokens do vetor:")
        print(tokens[:50])

        # 5. Salvar a saída em um arquivo (opcional, mas bom para o repo)
        with open('output_tokens.txt', 'w', encoding='utf-8') as f_out:
            f_out.write(str(tokens))

    except FileNotFoundError:
        print("Erro: O arquivo 'livro.txt' não foi encontrado.")

if __name__ == "__main__":
    main()


    