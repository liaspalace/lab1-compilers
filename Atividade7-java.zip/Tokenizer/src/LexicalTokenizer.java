import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LexicalTokenizer {
    private static final String regex =
            "\\p{L}+(?:[-']\\p{L}+)*|\\d+(?:[.,]\\d+)*|[.,;:!?()\"“”‘’—-]"; //regex para avaliar palavras em portugues incluindo pontuacoes da lingua

    public static List<String> tokenize(String sourcePath) throws IOException {
        String text = Files.readString(Paths.get(sourcePath), StandardCharsets.UTF_8);//faz a leitura da file em UTF_8
        Pattern pattern = Pattern.compile(regex); //transforma o regex em um automato fininito
        Matcher matcher = pattern.matcher(text); //procura no texto pelo padrao definido no regex

        List<String> tokens = new ArrayList<>();//cria uma lista para adicionar cada token encontrado pelo matcher
        while (matcher.find()) {
            tokens.add(matcher.group());//adiciona cada token
        }
        return tokens;
    }
    public static void main(String[] args) throws Exception {
        List<String> tokens = tokenize("src/Quincas_Borba.txt");//carrega o arquivo
        //printa a lista de tokens
        System.out.print("[");
        for (int i = 0; i < tokens.size()/5; i++) {
            System.out.print("\"" + tokens.get(i) + "\"");
            if (i < tokens.size() - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}
